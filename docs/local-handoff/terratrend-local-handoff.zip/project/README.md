# TerraTrend — Earth Change Observatory

TerraTrend is a NASA Space Apps project for investigating environmental change across whole geographic areas. The original analysis engine and chart tools now sit behind a map-first interface inspired by Kaspersky Cybermap, using the globe geometry from the sibling TerraTrend 2 project.

## Run

From this repository’s root:

```bash
./start.sh 8517
```

Open <http://127.0.0.1:8517>. Stop any older TerraTrend server on that port first, then start this version and reload the browser. The new frontend needs the new backend routes; refreshing an already-running Python process does not reload its code.

The startup script uses a project virtual environment and installs missing Python dependencies from `requirements.txt` (NumPy, SciPy, Requests and NetCDF4). JavaScript libraries are bundled locally. `pytest` is needed for the Python test command below.

## Investigation workflow

1. Choose **Continent**, **Subcontinent**, **Country**, or **Region**. The scope selector limits the displayed units. Ghana’s 16 administrative regions are bundled; other countries request ADM1 boundaries on demand when online access is available.
2. Click the blue **A / Primary area** card or amber **B / Comparison area** card to choose the target. Pick a whole boundary, draw a freehand/clicked **Lasso**, enter **Lat / Lon** bounds, or place a **Circle**/**Square** centre and adjust its size in kilometres. Custom shapes show approximate area; choose **Use for area A/B** to commit. A and B keep independent methods and stay selected when the displayed geographic level changes.
3. Use the persistent **selection icon at the bottom right** to open the compact icon rail. Hover/focus a tool for its label. The settings card opens only when a method needs controls; closing it leaves the rail accessible. Clear A/B with its × button, or click an already selected boundary again.
4. Open **Variables**, select up to three variables, choose a data source and a period of at least nine years.
5. Choose **Analyze** explicitly. Selecting an area prepares an investigation; it does not start a scientific request automatically.
6. Use **Analyze Layer** to calculate a separate trend for every area currently displayed. Results are calculated independently at each level. Missing data have their own status.
7. Open **Analysis** for series, statistical details, native-cell summaries, expanded charts and CSV export. Open **Compare** and choose two different units for an A/B analysis using the same variables and dates.
8. Open **Interconnections** to screen local candidate drivers, remote responses and simultaneous associations. Click a computed map connection for its evidence. **Globe / plane** switches the projection while retaining geographic identities.

## Scientific data

The default source is **NASA MERRA-2 · automatic**, using GES DISC datasets available through the challenge’s **Giovanni** resource. Open **Data & Methods**, generate a user token in your [NASA Earthdata profile](https://urs.earthdata.nasa.gov/profile), and connect it there. The app verifies authorization by reading one real temperature cell. The token stays in server memory for that session; it is not saved to the browser or repository. A server operator can instead provide `EARTHDATA_TOKEN` in the process environment.

If the running server is older than these files, the UI shows **RESTART SERVER** and opens setup. It does not silently change to cache-only data. Stop that Python process with Ctrl+C, run `./start.sh 8517` from this folder and reload. Measurements without an automatic source mapping are marked in the variable controls; cached data remain available only when explicitly selected.

After connecting, **Analyze** discovers published monthly granules in NASA CMR, downloads only the requested native grid windows through OPeNDAP, applies provider masks and verified unit conversions, clips cells to the exact selected polygon, and caches validated subsets. Progress and cancellation cover downloading as well as calculations. No manual data uploads are required. Large first-time requests can take minutes; subsequent analyses reuse cached data.

| Automatic measurement | NASA collection / field | Conversion |
| --- | --- | --- |
| Air temperature | M2TMNXSLV / T2M | K → °C |
| Surface temperature | M2TMNXSLV / TS | K → °C |
| Specific humidity | M2TMNXSLV / QV2M | kg/kg → g/kg |
| Surface pressure | M2TMNXSLV / PS | Pa → kPa |
| Root-zone / surface soil moisture | M2TMNXLND / GWETROOT, GWETTOP | Saturation fraction retained |
| Land evaporation | M2TMNXLND / EVLAND | kg m⁻² s⁻¹ → mm/day |
| Precipitation | M2TMNXFLX / PRECTOTCORR | kg m⁻² s⁻¹ → mm/day |

All three collections use version **5.12.4**, with a native grid of **0.625° longitude × 0.5° latitude**. Other catalogue fields require separate verified mappings; they are rejected explicitly for automatic analysis, and automatic scans/relationship screening use supported fields. Monthly wind-component means are not substituted for mean wind speed, monthly maxima are not daily-maximum averages, and absorbed radiation is not substituted for direct normal irradiance.

On 14 November 2026, live CMR discovery returned **261 soil-moisture monthly granules for January 2005–September 2026**. The observation endpoint redirected to Earthdata authentication (HTTP 302 → login; following login returns 401). No Earthdata token is configured in this workspace. **A full live observation download therefore still requires the user’s account connection.** This is an authentication requirement, not evidence that the archive has no data. The old Hydrology Data Rods URL now redirects to a retirement notice; this integration uses the current OPeNDAP route.

The sparse **Existing project cache** remains available and is labeled as a legacy POWER access route not verified against the challenge resource list. Overlapping cached observations are retained while missing months remain missing. Advanced normalized CSV import remains available under a collapsed section in Data & Methods for existing datasets; it is optional.

**Analysis → Satellite imagery** retains the earlier satellite panel. Imagery access remains source-policy gated; the new MERRA-2 trend adapter does not enable satellite image products.

## Map navigation and panels

Vertical scrolling zooms; horizontal trackpad scrolling rotates the globe or pans the plane. Wheel units are normalized and each event is limited; close-up zoom and drag scale with camera altitude. Double-click the globe to start spinning; drag or use the rotation button to pause it. Drawing tools retain their own click/drag behavior.

Drag either floating panel by its heading/grip, or use arrow keys on the grip (Shift for larger steps). The −/+ button collapses or expands the panel. Positions are kept inside the map on resize, and position/collapse preferences are saved locally. Boundary downloads are cached per country; recently viewed administrative meshes are reused. Progressive mesh construction and cancellation keep the map responsive while switching countries.

## Methods and limits

Whole Polygon/MultiPolygon selections, including disconnected pieces present in the boundary dataset, are shared between the renderer and backend. Native cells are clipped to those polygons and weighted by overlap and `cos(latitude)`. This is a small-cell approximation, not an equal-area GIS integration. A month needs at least 80% area support; incomplete years are excluded from annual trend testing. Coarse data cannot resolve fine administrative differences simply because the map has sharper boundaries.

Theil–Sen and Mann–Kendall summarize annual trends, with confidence intervals, seasonal checks and OLS diagnostics. Actual calendar years preserve gaps in slope calculations. A/B inference uses common complete years and the paired difference series.

Interconnection screens use anomaly series, lag-search correction, full-family false discovery control and conditional diagnostics where sufficient data exist. They identify exploratory associations and possible lead relationships. They do not establish physical causation, explain a long-term trend by themselves, or measure atmospheric transport. Moving packets illustrate computed lead direction.

Continents and subcontinents use Natural Earth’s regional country membership. Transcontinental countries remain whole under that scheme. Administrative boundaries can be dated or unavailable, and small islands may be absent at the bundled 1:50m resolution.

## Validation

```bash
.venv/bin/python -m pytest backend -q -p no:cacheprovider
node --test tests/*.test.cjs
node --check frontend/app.js
node --check frontend/workflow.js
node --check frontend/earth-renderer.js
node --check frontend/selection-tools.js
node --check frontend/selection-geometry.js
node --check frontend/map-panels.js
```

See [implementation notes](docs/UI_OVERHAUL_IMPLEMENTATION.md) for the architecture, validated behavior, API and remaining work. The [integration review](docs/UI_OVERHAUL_REVIEW.md) records the original assessment. The pre-overhaul README is preserved as [historical documentation](docs/LEGACY_README.md); its demo claims and old workflow are not the current contract.
